package thiGK.ntu64131410;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HaThiKieuNganFitCmsBlogApplication {

	public static void main(String[] args) {
		SpringApplication.run(HaThiKieuNganFitCmsBlogApplication.class, args);
	}

}
