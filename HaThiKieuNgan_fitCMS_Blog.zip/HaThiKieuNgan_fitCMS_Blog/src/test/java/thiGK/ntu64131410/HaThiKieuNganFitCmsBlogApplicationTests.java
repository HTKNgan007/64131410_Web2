package thiGK.ntu64131410;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HaThiKieuNganFitCmsBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
